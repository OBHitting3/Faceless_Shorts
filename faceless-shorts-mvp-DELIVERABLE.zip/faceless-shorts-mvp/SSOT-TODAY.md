# SSOT — Today (Faceless Shorts / GrokFaceless)

**Date:** 2026-02-15  
**Focus:** One thing. Ship.

---

## DoD (Definition of Done)

**Functioning and orderable online.**

- **Functioning:** The product (Faceless Shorts MVP) works — buyer can run it or use what’s in the package.
- **Orderable online:** It’s on a sales page (Gumroad) so someone can pay and get it.

Ship something today even if it’s not 100% perfect.

---

## Out of scope today

- Runway/Midjourney/Pika integration (plan is in place for later).
- Temporal stitch frame / full event pipeline (after we have the spec from Gemini).
- Perfect polish.

---

## Today’s path

1. **Package:** Ensure `faceless-shorts-mvp` is zip-able and documented (README, setup, one-command run).
2. **Gumroad:** One product listing — “Faceless Shorts Automator MVP” — with price, description, and the ZIP (or clear “what you get”).
3. **Live:** Product is published and orderable. DoD met.

---

## Single source of truth

This file. Everything today traces to: functioning + orderable online.
