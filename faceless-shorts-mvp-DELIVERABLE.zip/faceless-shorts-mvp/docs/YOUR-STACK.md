# Your stack (so the pipeline uses what you have)

**AI / models**
- Quad Max
- Gemini Pro
- Perplexity
- One Pilot
- GPT Pro
- SuperGrok
- Cursor

**Video / image**
- Runway Unlimited
- Midjourney (paid)
- Pika (for the year)
- Pika Art
- “Banana” one

**Creators / workflow**
- TikTok Studio
- Slack
- Reddit
- Discord
- Notion
- Dropbox
- CapCut

**Rule:** Prefer your tools (Runway, Midjourney, Pika, etc.) over generic fallbacks. Ask what you have before assuming.
