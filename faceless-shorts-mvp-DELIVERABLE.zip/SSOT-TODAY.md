# SSOT — Today (Faceless Shorts / GrokFaceless)

**Date:** 2026-02-15  
**Focus:** One thing. Ship. **Nothing else** until this DoD is met.

---

## DoD (Definition of Done) — NOTHING else until this is done

**Shipped to Profiles and 50 other outlets.**

1. **Profiles:** Product live on Gumroad — functioning and orderable (buyer can pay and get it).
2. **50 other outlets:** Link/product listed or promoted at all 50 places in `docs/50-PLACES-NO-STATE-ID.md`. Track in `50-OUTLETS-SHIP-CHECKLIST.md`.

No other work. No distractions. Next thing only after this DoD is complete.

---

## Out of scope today

- Runway/Midjourney/Pika integration (plan is in place for later).
- Temporal stitch frame / full event pipeline (after we have the spec from Gemini).
- Perfect polish.
- Anything not required to meet the DoD above.

---

## Today’s path

1. **Package:** Deliverable ZIP `faceless-shorts-mvp-DELIVERABLE.zip` (no secrets). Create if missing.
2. **Gumroad (Profile):** Open GUMROAD-PASTE-TODAY.txt → Gumroad → New product → paste copy → set price → upload ZIP → Publish. Product live = “Profiles” done.
3. **50 outlets:** Open `50-OUTLETS-SHIP-CHECKLIST.md`. For each outlet: signup/post/list per instructions; paste Gumroad link; mark done. All 50 = DoD met.
4. **Done:** SSOT DoD complete. Then and only then discuss next thing.

---

## Single source of truth

This file. Everything today traces to: shipped to Profiles + 50 outlets.
