# 50 Outlets — Ship Checklist (DoD)

**DoD:** Product shipped to Profiles (Gumroad) + all 50 below. Mark [x] when done.

**Gumroad link (paste after publish):** _________________________________

**One-liner for bios/posts:** "Faceless Shorts Automator MVP – topic to YouTube Short in one flow. [Gumroad link]"

---

| # | Outlet | Action | Done |
|---|--------|--------|------|
| 1 | Gumroad | Product live, orderable (Profile) | [ ] |
| 2 | Twitter/X | Post + link to Gumroad | [ ] |
| 3 | Instagram | Reels/feed/Stories, link in bio | [ ] |
| 4 | TikTok | Post, link in bio | [ ] |
| 5 | Reddit | r/SideProject, r/nocode etc. (follow rules) | [ ] |
| 6 | LinkedIn | Post + link in comments | [ ] |
| 7 | YouTube | Short/video, Gumroad in description | [ ] |
| 8 | Pinterest | Pins + link to product | [ ] |
| 9 | Dev.to | Article, link to Gumroad | [ ] |
| 10 | Medium | Article, link in bio + article | [ ] |
| 11 | Substack | Newsletter/post with link | [ ] |
| 12 | Beehiiv | Landing page + emails | [ ] |
| 13 | ConvertKit | Forms + emails | [ ] |
| 14 | Mailchimp | Campaigns + link | [ ] |
| 15 | Linktree | Link-in-bio page → Gumroad | [ ] |
| 16 | Bio.link | Link-in-bio → Gumroad | [ ] |
| 17 | Carrd | One-page site, Gumroad link | [ ] |
| 18 | Notion | Public page, description + link | [ ] |
| 19 | Product Hunt | Launch product, link to Gumroad | [ ] |
| 20 | Indie Hackers | Share project + link | [ ] |
| 21 | Hacker News | Show HN or relevant thread (no pure spam) | [ ] |
| 22 | Discord | Allowed channels, share link | [ ] |
| 23 | Telegram | Channels/groups, share link | [ ] |
| 24 | Bluesky | Post + link | [ ] |
| 25 | Mastodon | Post + link (creator/tech instance) | [ ] |
| 26 | Threads | Cross-post, link in bio | [ ] |
| 27 | Quora | Answer questions, link where allowed | [ ] |
| 28 | Tumblr | Post + link | [ ] |
| 29 | GitHub | README "Buy the full MVP" link | [ ] |
| 30 | Hashnode | Blog post + Gumroad link | [ ] |
| 31 | Koji | Link-in-bio / mini-apps → Gumroad | [ ] |
| 32 | Beacons | Link-in-bio | [ ] |
| 33 | Taplink | Link-in-bio | [ ] |
| 34 | Snapchat | Stories, link in profile | [ ] |
| 35 | Twitch | Stream, link in description | [ ] |
| 36 | YouTube Community tab | Post with link | [ ] |
| 37 | Reddit (alt subs) | r/Entrepreneur, r/MakeCom, r/YouTubeCreators | [ ] |
| 38 | Facebook Profile | Post to profile + link | [ ] |
| 39 | Facebook Groups | "Promo allowed" groups, link in comments | [ ] |
| 40 | Slack communities | #showcase / #promo if allowed | [ ] |
| 41 | Lemlist / cold email | Outreach with link | [ ] |
| 42 | Gumroad Discover | Optimize listing (title, description, tags) | [ ] |
| 43 | Payhip | List product, link/same promo | [ ] |
| 44 | Lemon Squeezy | Seller signup, list product | [ ] |
| 45 | Patreon | Page link to Gumroad one-time buy | [ ] |
| 46 | Buy Me a Coffee | Link to Gumroad | [ ] |
| 47 | Ko-fi | Link to Gumroad | [ ] |
| 48 | Creator/no-code directories | Submit form + link (NoCode Tech, etc.) | [ ] |
| 49 | Your own domain + host | Vercel/Netlify/GitHub Pages: "Faceless Shorts – get on Gumroad" + link | [ ] |
| 50 | Email signature / contact | Add Gumroad link to email sig or contact page | [ ] |

**Note:** Gumroad = Profile (outlet #1). Rows 2–50 = the 50 other outlets. DoD = all 50 boxes marked.

---

**DoD met when:** Gumroad live + all checkboxes above marked [x].
